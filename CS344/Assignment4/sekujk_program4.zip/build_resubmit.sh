#!/bin/bash
gcc -std=c99 -pthread -o line_processor line_processor.c